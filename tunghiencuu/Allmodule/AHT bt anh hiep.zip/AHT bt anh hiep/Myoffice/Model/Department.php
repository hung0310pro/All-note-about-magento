<?php
namespace AHT\Myoffice\Model;

class Department extends \Magento\Framework\Model\AbstractModel
{

    protected function _construct()
    {
        $this->_init('AHT\Myoffice\Model\ResourceModel\Department');
    }

}
